# Filename:         makeTheBigFile.py
# Author:           Dylan Gaspar
# Class:            GA
# Last Modified:    04/04/2018
# Purpose:          Take all 9 excel files for each of the 5
#                   heuristics with and without NBHD search

import math
import xlrd
from xlrd import open_workbook
import xlwt
import random
import operator
from operator import itemgetter
import os 

def main():

    # sheet.write(row, col, value)
    newBook = xlwt.Workbook(encoding="utf-8")
    newSheet = newBook.add_sheet("Sheet1")
    
    classSize = 10
    
    heuristics = ["TBO", "LBO", "TLBO", "Jaya", "JTLBO"]
    
    huerFolder = "_10PercentRHSofDemand_200ItrsMax_10ItrsEarlyTerm"
    JTLBOFolder = "_10PercentRHSofDemand_200ItrsMax_5ItrsEarlyTerm"
    
    noNBHDFolder = "SeededNBHDnoneRepairUnique"
    NBHDFolder = "SeededNBHDonceRepairUnique"
    NBHDs = [noNBHDFolder, NBHDFolder]
    
    #mdmkpc10p_rep_wJTLBO_seeded_NBHD_none_Repair_Unique_JTLBO
    
    currDir = os.path.dirname(__file__)
    
    newColNo = -1
    
    # choose a heuristic
    for heuristic in heuristics:
        outerFolder = heuristic
        if heuristic == "JTLBO":
            outerFolder = heuristic + JTLBOFolder
        else:
            outerFolder = heuristic + huerFolder
            
        # choose NBHD search or not
        for NBHD in NBHDs:
            newColNo += 1
            nbhdFlag = ""
            innerFolder = NBHD
            if NBHD == noNBHDFolder:
                nbhdFlag = "none"
            else:
                nbhdFlag = "once"
            filename = "mdmkpc10p_rep_w" + heuristic + "_seeded_NBHD_" + nbhdFlag + "_Repair_Unique_" + heuristic + ".xlsx"
            relPath = outerFolder + "/" + innerFolder + "/" + filename
            absFilePath = os.path.join(currDir, relPath)
            
            # title for each column in myBook
            title = heuristic + "_" + nbhdFlag
            
            # open the single file for one heuristic of NBHD or none
            myBook = open_workbook(absFilePath,on_demand=True)
            
            # should be only one sheet
            for name in myBook.sheet_names():
                mySheet = myBook.sheet_by_name(name)
                firstEltRow = 3
                firstEltCol = 6
                datasetRowLength = 19
                caseColLength = 6
                beatCplex = 0
                for dataset in range(9):
                    for case in range(6):
                        for problem in range(15):
                            perDev= mySheet.cell(firstEltRow +dataset*datasetRowLength +problem,firstEltCol +case*caseColLength).value
                            print perDev, problem+case*15+dataset*90
                            perDev = float(perDev)
                            if perDev < 0:
                                perDev = 0.0
                                beatCplex += 1
                            newSheet.write(1+problem +case*15 +dataset*90, 4+newColNo, perDev)
                newSheet.write(815, 4+newColNo, "Beat Cplex")
                newSheet.write(816, 4+newColNo, beatCplex)
                myBook.unload_sheet(name)
                
            myBook.release_resources()
    
    
            newBook.save('mdmkpc10pc_ct_WithAndWithoutNBHD_TBO_LBO_TLBO_Jaya_JTLBO.xls')
    
    
    
    
    
    
    
    
    
    
    

if __name__ == '__main__':
	main()

