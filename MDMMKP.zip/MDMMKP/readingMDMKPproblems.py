# Filename:         readingMDMKPproblems.py
# Author:           Dylan Gaspar
# Class:            GA
# Last Modified:    9/25/2016
# Purpose:          reads in MDMKP problems from local text files and 
#                   prints out the generated constraints and objective
#                   functions

import math
import xlwt
#import random

def main():
    filename='mdmkp_ct3'
    with open(filename+'.txt') as file:
        defsNo=int(file.readline())
        # defsNo=1
        '''
        elConst = []
        egConst = []
        objFuncts = []
        '''
        probNo = 1
        
    
        # for each problem definition,
        for definition in range(defsNo):
        
            # get the number of vars and constraints
            params = file.readline().split(' ')
            varsNo = int(params[0])
            constNo = int(params[1])
            
            # define list of <= and >= constraints and obj functs
            elConst = []
            egConst = []
            objFuncts = []
            
            # get the <= constraints
            for constraint in range(constNo):
                const = file.readline().split(' ')
                const.remove('\n')
                elConst.append(const)
            # get the rhs vals in varsNo+1th position in each list
            elrhs = file.readline().split(' ')
            elrhs.remove('\n')
            index=0
            for rhs in elrhs:
                elConst[index].append(rhs)
                index+=1
            
            # get the >= constraints
            for constraint in range(constNo):
                const = file.readline().split(' ')
                const.remove('\n')
                egConst.append(const)
            # get the rhs vals in varsNo+1th position in each list
            egrhs = file.readline().split(' ')
            egrhs.remove('\n')
            index=0
            for rhs in egrhs:
                egConst[index].append(rhs)
                index+=1
            
            # get 6 obj functs
            for n in range(6):
                funct = file.readline().split(' ')
                funct.remove('\n')
                objFuncts.append(funct)
                
               



               
            book = xlwt.Workbook(encoding="utf-8")
            shtNo=1
                
            # write to excel spreadsheet
            for funct in objFuncts:
                sheet = book.add_sheet("Sheet " + str(shtNo))
                index=0
                for coeff in funct:
                    # .write(row, col, value)
                    sheet.write(5,index+3,coeff)
                    index+=1
                m=0
                for constraint in elConst:
                    for idx in range(varsNo):
                        sheet.write(m+7,idx+3,constraint[idx])
                    sheet.write(m+7,varsNo+1+3,'<=')
                    sheet.write(m+7,varsNo+2+3,constraint[varsNo])
                    m+=1
                for constraint in egConst:
                    for idx in range(varsNo):
                        sheet.write(m+7,idx+3,constraint[idx])
                    sheet.write(m+7,varsNo+1+3,'>=')
                    sheet.write(m+7,varsNo+2+3,constraint[varsNo])
                    m+=1
                shtNo+=1
                sheet.write(1,3,'variables=')
                sheet.write(1,4,varsNo)
                sheet.write(2,3,'constraints=')
                sheet.write(2,4,constNo)
                
            book.save(filename + '_' + str(probNo) + '.xls')
            probNo+=1
                
            '''
            # show that everything was read in correctly
            print '\nProblem Number: ' + str(probNo)
            print 'Number of Variables: ' + str(varsNo)
            print 'Number of <= Constraints: ' + str(constNo)
            print '\nConstraints: <='
            for constraint in elConst:
                n = 1
                for coeff in constraint:
                    if n < varsNo:
                        print str(coeff) + 'X' + str(n) + ' + ',
                    elif n == varsNo:
                        print str(coeff) + 'X' + str(n) + ' <= ',
                    else:
                        print str(coeff)
                    n+=1
                    
            print '\nConstraints: >='
            for constraint in egConst:
                n = 1
                for coeff in constraint:
                    if n < varsNo:
                        print str(coeff) + 'X' + str(n) + ' + ',
                    elif n == varsNo:
                        print str(coeff) + 'X' + str(n) + ' >= ',
                    else:
                        print str(coeff)
                    n+=1
                    
            print '\nObjective Functions'
            for funct in objFuncts:
                n = 1
                for coeff in funct:
                    if n < varsNo:
                        print str(coeff) + 'X' + str(n) + ' + ',
                    elif n == varsNo:
                        print str(coeff) + 'X' + str(n) + ' = Z'
                    n+=1
            probNo+=1
            '''
            
            
            #for objFunct in objFuncts:
                

        
if __name__ == '__main__':
	main()


