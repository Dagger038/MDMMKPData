# Filename:         puttingTogetherData.py
# Author:           Dylan Gaspar
# Class:            GA
# Last Modified:    12/19/2016
# Purpose:          

import math
import xlrd
from xlrd import open_workbook
import xlwt
import random
import operator
from operator import itemgetter

def main():
    
    classSize = 10

    filename='mdmkpc10p_rep.xlsx'
    refBook = open_workbook(filename,on_demand=True)
    refName = ""
    for named in refBook.sheet_names():
        refName = named
    refSheet = refBook.sheet_by_name(refName)
    
    for dataSet in [1,2,3,4,5,6,7,8,9]:
        
    
        # sheet.write(row, col, value)
        book = xlwt.Workbook(encoding="utf-8")
        
        sheet = book.add_sheet("Sheet1")
        
        refRowOffset = 3 + (15 + 4) * (dataSet - 1)
        
        myColOffset = 7 + ((100 if dataSet % 3 == 1 else 250 if dataSet % 3 == 2 else 500)/classSize)
        
        myRowCurr = 6
        
        finalRow = 2
        finalCol = 1
        
        for refColNum in range(0,6):
        
            filename='mdmkp_ct'+str(dataSet)+'Debug_100itr_Jaya.xls'
            myBook = open_workbook(filename,on_demand=True)
        
            refColOffset = 4 + 3*refColNum
        
            refRowCurr = refRowOffset -1
            
            myRowCurr+=1
            
            for name in myBook.sheet_names():
            
                mySheet = myBook.sheet_by_name(name)
                
                refRowCurr +=1
        
                # sheet.cell(row,col).value
        
                # optimal
                sheet.write(finalRow, finalCol, refSheet.cell(refRowCurr,refColOffset).value)
                # jaya
                jayaVal = mySheet.cell(myRowCurr,myColOffset).value
                sheet.write(finalRow, finalCol+1, jayaVal)
                finalRow+=1
        
                myBook.unload_sheet(name)
                
            myBook.release_resources()
    
            
    
    
        book.save('mdmkpc10pc_ct'+dataSet+'_100itr.xls')
    
    


if __name__ == '__main__':
	main()

